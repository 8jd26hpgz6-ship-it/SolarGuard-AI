# SolarGuard AI — Final Run Manifest

## Execution evidence
- Runtime: Google Colab with CUDA available; device reported as **Tesla T4** in the supplied execution screenshot.
- Source dataset: Raptor Maps InfraredSolarModules, 20,000 source images.
- Duplicate audit: 22 groups with byte-identical image files; 6 conflicting-label groups; 12 conflicting-label images excluded; 16 additional same-label duplicates removed; 19,972 retained images.
- Stratified split (seed 42): 13,980 train / 2,996 validation / 2,996 test.
- Configurations: CNN + Cross-Entropy; CNN + CBAM + Cross-Entropy; CNN + Focal Loss; CNN + CBAM + Focal Loss.
- Training seeds: 42, 43, 44 for each configuration.
- Evaluation rows: 144 (4 configurations × 3 seeds × 12 conditions).
- Training budget: up to 50 epochs; early-stopping patience 8; best checkpoint selected using validation Macro-F1.
- The run log records the individual per-configuration, per-seed training times. The sum of the 12 model-fit times is approximately 544.76 seconds; it excludes dataset download/extraction and test evaluation.

## Clean test results (mean ± sample SD across three seeds)
| Configuration | Accuracy | Macro-F1 | Macro-recall | Best validation Macro-F1 |
|---|---:|---:|---:|---:|
| CNN + CE | 0.7432 ± 0.0151 | 0.5209 ± 0.0529 | 0.4964 ± 0.0551 | 0.5266 ± 0.0492 |
| CNN + CBAM + CE | 0.7540 ± 0.0083 | 0.5512 ± 0.0233 | 0.5176 ± 0.0245 | 0.5586 ± 0.0200 |
| CNN + Focal | 0.7314 ± 0.0088 | 0.4957 ± 0.0411 | 0.4628 ± 0.0449 | 0.5203 ± 0.0199 |
| CNN + CBAM + Focal | 0.7421 ± 0.0081 | 0.5188 ± 0.0217 | 0.4820 ± 0.0193 | 0.5222 ± 0.0126 |

## Interpretation guardrails
- CNN + CBAM + Cross-Entropy had the highest mean clean-test Macro-F1 in this run (0.5512) and accuracy (75.40%).
- This is a descriptive comparison across three seeds; no formal statistical significance test was performed.
- Focal Loss did not improve the mean clean-test Macro-F1 in the tested configurations.
- Minority-class recall remains weak, especially for Soiling. A better aggregate score does not imply improvement for every class.
- Brightness perturbations in the code are **additive offsets** to normalized pixel values (−0.4, −0.2, +0.2, +0.4), not percentage changes. Contrast is scaled around each image mean; Gaussian noise uses σ = 0.05, 0.10, 0.20.
- The perturbation tests measure sensitivity to image-space changes only; they do not establish field robustness or calibrated temperature robustness.

## Package contents
- `code/`: training and summarization scripts, dependency list, AI disclosure, source-code screenshots, Colab run screenshots.
- `colab/`: runnable Colab notebook used for the four-configuration run.
- `results/outputs/`: raw CSV, duplicate audit, split distributions, per-class reports, confusion matrices, and training histories.
- `results/run_log.txt`: full training and evaluation log.

Model weight files are not included in the result bundle (the Colab export explicitly omitted `*.pt` files). The public dataset is also not duplicated in this package; the notebook downloads it from the Raptor Maps repository.
